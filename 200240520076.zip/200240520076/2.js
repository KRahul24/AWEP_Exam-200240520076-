function fun()
{
    var x=document.getElementById("nameid").value;
    if(x=="")
    {
        alert("Entering name is must!");
    }

    var y=document.getElementById("passid").value;
    if(y=="")
    {
        alert("Password must be filled!");
    }

    var z=document.getElementById("mailid").value;
    if(z=="")
    {
        alert("Email must be filled!");
    }

    var a = document.getElementById("nameid").value;
    var b = document.getElementById("passid").value;
    var c = document.getElementById("mailid").value;
    var s= document.getElementById("displayform");
    s.textContent="Username is:"+a+"Password is:"+b+" Email id is:"+c;

    document.getElementById("nameid").value="";
    document.getElementById("passid").value="";
    document.getElementById("mailid").value="";
}